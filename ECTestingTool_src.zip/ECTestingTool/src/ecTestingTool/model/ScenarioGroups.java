package ecTestingTool.model;

import java.util.ArrayList;
import java.util.List;


public class ScenarioGroups extends AbstractModelObject  {
	private List<ScenarioGroup> m_groups = new ArrayList<ScenarioGroup>();
	public void addGroup(ScenarioGroup group) {
		List<ScenarioGroup> oldValue = m_groups;
		m_groups = new ArrayList<ScenarioGroup>(m_groups);
		m_groups.add(group);
		firePropertyChange("groups", oldValue, m_groups);
	}

	public void removeGroup(ScenarioGroup group) {
		List<ScenarioGroup> oldValue = m_groups;
		m_groups = new ArrayList<ScenarioGroup>(m_groups);
		m_groups.remove(group);
		firePropertyChange("groups", oldValue, m_groups);
	}

	public List<ScenarioGroup> getGroups() {
		return m_groups;
	}
}
