package ecTestingTool.model;

public class Scenario extends AbstractModelObject  {
	private String ec_scenamrioName;
	private String ec_requestType;
	private String ec_diameterPath;
	private String ec_configuredAVP;
	private String ec_commandType;
	private String ec_scenarioID;
	public Scenario(String id,String avp) {
		ec_scenarioID=id;
		ec_scenamrioName="Demo";
		this.setEc_requestType("Initial");
		this.setEc_configuredAVP(avp);
		this.setEc_commandType("CCR-CCA");
	}
	
	public Scenario(String ec_scenarioID,String ec_scenamrioName, String ec_requestType,
			 String ec_configuredAVP,String ec_configuredType) {
		super();
		this.ec_scenarioID = ec_scenarioID;
		this.ec_scenamrioName = ec_scenamrioName;
		this.ec_requestType = ec_requestType;		
		this.setEc_configuredAVP(ec_configuredAVP);
		this.setEc_commandType(ec_configuredType);
	}

	public String getEc_requestType() {
		return ec_requestType;
	}
	public void setEc_requestType(String requestType) {
		String oldValue = ec_requestType;
		this.ec_requestType = requestType;
		firePropertyChange("ec_requestType", oldValue, ec_requestType);
	}
	public String getEc_scenamrioName() {
		return ec_scenamrioName;
	}
	public void setEc_scenamrioName(String scenamrioName) {
		String oldValue = ec_scenamrioName;
		this.ec_scenamrioName = scenamrioName;
		firePropertyChange("ec_scenamrioName", oldValue,ec_scenamrioName);
	}

	public String getEc_diameterPath() {
		return ec_diameterPath;
	}

	public void setEc_diameterPath(String diameterPath) {
		String oldValue = ec_diameterPath;
		this.ec_diameterPath = diameterPath;
		firePropertyChange("ec_diameterPath", oldValue,ec_diameterPath);
	}

	public String getEc_configuredAVP() {
		return ec_configuredAVP;
	}

	public void setEc_configuredAVP(String ec_configuredAVP2) {
		String oldValue = ec_configuredAVP;
		this.ec_configuredAVP = ec_configuredAVP2;
		firePropertyChange("ec_configuredAVP", oldValue,ec_configuredAVP);
	}
	public String getScenarioData() {
		return getEc_scenarioID()+";"+getEc_scenamrioName()+";"+getEc_requestType()+";"+getEc_configuredAVP()+";"+getEc_commandType();
		
	}

	public String getEc_scenarioID() {
		return ec_scenarioID;
	}

	public void setEc_scenarioID(String ec_scenarioID) {
		String oldValue = ec_scenarioID;
		this.ec_scenarioID = ec_scenarioID;
		firePropertyChange("ec_scenarioID", oldValue,ec_scenarioID);
	}

	public String getEc_commandType() {
		return ec_commandType;
	}

	public void setEc_commandType(String ec_commandType) {
		String oldValue = ec_commandType;
		this.ec_commandType = ec_commandType;
		firePropertyChange("ec_commandType", oldValue,ec_commandType);
	}
	
}
