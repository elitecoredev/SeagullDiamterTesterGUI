package ecTestingTool.model;
import java.util.ArrayList;
import java.util.List;

public class ScenarioGroup extends AbstractModelObject {
	private List<Scenario> m_scenario = new ArrayList<Scenario>();
	private String m_name;
	private String m_ip_port;
	private String m_host_id;
	private String m_app_id;
	private String m_realm;
	public ScenarioGroup() {
		// TODO Auto-generated constructor stub
	}
		

	public ScenarioGroup( String m_name,
			String m_ip_port, String m_host_id, String m_app_id, String m_realm) {
		super();				
		this.m_name = m_name;
		this.m_ip_port = m_ip_port;
		this.m_host_id = m_host_id;
		this.m_app_id = m_app_id;
		this.m_realm = m_realm;
	}
	public ScenarioGroup(List<Scenario> m_scenario, String m_name) {
		super();
		this.m_scenario = m_scenario;
		this.m_name = m_name;
	}
	public ScenarioGroup(String m_name) {
		super();
		this.m_name = m_name;
	}


	public String getName() {
		return m_name;
	}

	public void setName(String name) {
		String oldValue = m_name;
		m_name = name;
		firePropertyChange("name", oldValue, m_name);
	}
	public void addScenario(Scenario scenario) {
		List<Scenario> oldValue = m_scenario;
		m_scenario = new ArrayList<Scenario>(m_scenario);		
		m_scenario.add(scenario);
		firePropertyChange("scenarios", oldValue, m_scenario);
		firePropertyChange("scenarioCount", oldValue.size(), m_scenario.size());
	}

	public void removeScenario(Scenario scenario) {
		List<Scenario> oldValue = m_scenario;
		m_scenario = new ArrayList<Scenario>(m_scenario);
		m_scenario.remove(scenario);
		firePropertyChange("scenarios", oldValue, m_scenario);
		firePropertyChange("scenarioCount", oldValue.size(), m_scenario.size());
	}
	public List<Scenario> getScenarios() {
		return m_scenario;
	}
	
	public int getScenarioCount() {
		return m_scenario.size();
	}
	public String getIpport() {
		return m_ip_port;
	}
	public void setIpport(String m_ip_port) {
		String oldValue = m_ip_port;
		this.m_ip_port = m_ip_port;
		firePropertyChange("ipport", oldValue, m_ip_port);
	}
	public String getHostid() {
		return m_host_id;
	}
	public void setHostid(String m_host_id) {
		String oldValue = m_host_id;
		this.m_host_id = m_host_id;
		firePropertyChange("hostid", oldValue, m_host_id);
	}
	public String getAppid() {
		return m_app_id;
	}
	public void setAppid(String m_app_id) {
		String oldValue = m_app_id;
		this.m_app_id = m_app_id;
		firePropertyChange("appid", oldValue, m_app_id);
	}
	public String getRealm() {
		return m_realm;
	}
	public void setRealm(String m_realm) {
		String oldValue = m_realm;
		this.m_realm = m_realm;
		firePropertyChange("realm", oldValue, m_realm);
	}
}
