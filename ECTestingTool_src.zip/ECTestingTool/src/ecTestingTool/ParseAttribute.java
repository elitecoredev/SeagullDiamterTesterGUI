package ecTestingTool;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.tree.DefaultMutableTreeNode;

public class ParseAttribute extends JFrame {
	/**
	 * 
	 */
	private static final int END_OF_STRING = -1;
	private static final boolean END_OF_LIST=true;
	private static final String NAME = "<avp name=\"";
	private static final String DOUBLEQUOTES = "\"";
	private static final String VALUE = " value=\"";
	private static final String CLOSINGBRACKET = ">";
	private static final String CLOSINGAVP = "</avp>";
	private static final String NEXTLINE = "\n";
	private static final String TAB = "\t";
	

	static boolean isWhitespace(char ch) {
		return (ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n'  || ch == '\f' || ch == ',');
	}
	private boolean isOperator(char ch1) {
		String ch=String.valueOf(ch1);
		return(ch .equals("=") || ch.equals("{") || ch.equals("}")  );
	}

	private boolean isEscape(char currentChar) {
		return (currentChar == '\\');
	}

	public List<String> parse(String expression){
		List<String> list = new ArrayList<String>();
		StringReader stringReader = new StringReader(expression);
		int currentChar = 0;
		StringBuilder currentSymbol = new StringBuilder();
		try {
			while((currentChar=stringReader.read())!= END_OF_STRING)
			{
				if(isWhitespace((char)currentChar)){
					if(currentSymbol.length() > 0 ){
						String symbol = currentSymbol.toString();
						currentSymbol = new StringBuilder();
						list.add(symbol);
					}
					continue;
				}
				if(isOperator((char)currentChar)){
					if(currentSymbol.length() > 0 ){
						String symbol = currentSymbol.toString();
						currentSymbol = new StringBuilder();
						list.add(symbol);
					}
					String operatorSymbol = String.valueOf((char)currentChar);
					list.add(operatorSymbol);
					continue;
				}
				if(((char)currentChar) == '"') {
					String symbol = readLiteral(stringReader);
					list.add(symbol);
					continue;
				}
				currentSymbol.append((char) currentChar);
			} 
			//if still the current Symbol has some values
			if(currentSymbol.length() > 0 ){
				String symbol = currentSymbol.toString();
				currentSymbol = new StringBuilder();
				list.add(symbol);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}

	public String readLiteral(StringReader stringReader) {
		int currentChar = END_OF_STRING;
		StringBuilder literal = new StringBuilder();
		try {
			currentChar = stringReader.read();
		}catch (IOException e) {
		}
		while((char)currentChar != '"'){
			if(currentChar == END_OF_STRING){
				//throw 
			}
			if(isEscape((char)currentChar)){
				try {
					currentChar = stringReader.read();
					literal.append((char)currentChar);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}else{
				literal.append((char)currentChar);
			}
			try{
				currentChar = stringReader.read();
			}catch (IOException e) {
				e.printStackTrace();
			}
		}
		return literal.toString(); 
	}

	public DefaultMutableTreeNode getTreeNode(List<String> symbolList){

		DefaultMutableTreeNode treeNode = new DefaultMutableTreeNode("AVP");
		Iterator<String> iterator= symbolList.iterator();
		String previous,current,next;
		previous=current=next=null;

		while(iterator.hasNext()==END_OF_LIST){
			current=iterator.next();

			if(current.equals("=")){
				next=iterator.next();
				treeNode.add(new DefaultMutableTreeNode(new String(previous+current+next)));
				continue;
			}else if(current.equals("{")){
				DefaultMutableTreeNode subtreeNode = new DefaultMutableTreeNode(new String (previous));
				treeNode.add(subtreeNode);
				subtreeNode=getGroupedAttribute(previous,subtreeNode,iterator);
			}
			previous=current;
		}

		return treeNode;
	}

	public DefaultMutableTreeNode getGroupedAttribute(String head,DefaultMutableTreeNode treeNode,Iterator<String> iterator){
		String previous,current,next;
		previous=current=next=null;

		while(!(current=iterator.next()).equals("}")){
			if(current.equals("=")){
				next=iterator.next();
				treeNode.add(new DefaultMutableTreeNode(new String(previous+current+next)));
				continue;
			}else if(current.equals("{")){
				DefaultMutableTreeNode subtreeNode = new DefaultMutableTreeNode(new String (previous));
				treeNode.add(subtreeNode);
				subtreeNode=getGroupedAttribute(previous,subtreeNode,iterator);
			}
			previous=current;
			//previous=head+" . "+current;
		}
		return treeNode;
	}
	public String getAvpString(List<String> symbolList){

		StringBuilder avpString=new StringBuilder();
		Iterator<String> iterator= symbolList.iterator();
		String previous,current,next;
		previous=current=next=null;
		Integer tab = new Integer(2);

		while(iterator.hasNext()==END_OF_LIST){
			current=iterator.next();

			if(current.equals("=")){
				next=iterator.next();

				for(int i=0;i<tab;i++)
					avpString.append(TAB);

				avpString.append(NAME);
				avpString.append(previous);
				avpString.append(DOUBLEQUOTES);
				avpString.append(VALUE);
				avpString.append(next);
				avpString.append(DOUBLEQUOTES);
				avpString.append(CLOSINGBRACKET);
				avpString.append(CLOSINGAVP);
				avpString.append(NEXTLINE);

				continue;
			}else if(current.equals("{")){

				for(int i=0;i<tab;i++)
					avpString.append(TAB);

				avpString.append(NAME);
				avpString.append(previous);
				avpString.append(DOUBLEQUOTES);
				avpString.append(CLOSINGBRACKET);
				avpString.append(NEXTLINE);
				getGroupedAvp(previous,avpString,iterator,++tab);
				--tab;
				
				for(int i=0;i<tab;i++)
					avpString.append(TAB);
				avpString.append(CLOSINGAVP);
				avpString.append(NEXTLINE);
			}
			previous=current;
		}

		return avpString.toString();
	}

	private void getGroupedAvp(String head,StringBuilder avpString,Iterator<String> iterator,Integer tab){
		String previous,current,next;
		previous=current=next=null;

		while(!(current=iterator.next()).equals("}")){
			if(current.equals("=")){
				next=iterator.next();
				
				for(int i=0;i<tab;i++)
					avpString.append(TAB);
				
				avpString.append(NAME);
				avpString.append(previous);
				avpString.append(DOUBLEQUOTES);
				avpString.append(VALUE);
				avpString.append(next);
				avpString.append(DOUBLEQUOTES);
				avpString.append(CLOSINGBRACKET);
				avpString.append(CLOSINGAVP);
				avpString.append(NEXTLINE);
				continue;
			}else if(current.equals("{")){
				
				for(int i=0;i<tab;i++)
					avpString.append(TAB);
				
				avpString.append(NAME);
				avpString.append(previous);
				avpString.append(DOUBLEQUOTES);
				avpString.append(CLOSINGBRACKET);
				avpString.append(NEXTLINE);
				
				
				getGroupedAvp(previous,avpString,iterator,++tab);
				--tab;
				
				for(int i=0;i<tab;i++)
					avpString.append(TAB);
				avpString.append(CLOSINGAVP);
				avpString.append(NEXTLINE);
			}
			previous=current;
		}
	}

	}