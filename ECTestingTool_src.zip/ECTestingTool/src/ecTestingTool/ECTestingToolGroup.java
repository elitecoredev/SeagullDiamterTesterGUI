package ecTestingTool;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.MatteBorder;

import org.jdesktop.beansbinding.AutoBinding;
import org.jdesktop.beansbinding.BeanProperty;
import org.jdesktop.beansbinding.Bindings;
import org.jdesktop.swingbinding.JComboBoxBinding;
import org.jdesktop.swingbinding.SwingBindings;

import ecTestingTool.model.ScenarioGroup;

public class ECTestingToolGroup extends JDialog  {
	private static final long serialVersionUID = 1L;
	private final ecTestingTool.model.ScenarioGroup ec_scenariogroup;
	
	private final List<String> m_names;	
	private JPanel m_contentPane;
	private JButton m_buttonOk;
	private JComboBox m_comboBox;
	JTextField host_id;
	JTextField realm;
	JTextField app_id;
	JTextField ip_port;
	public ECTestingToolGroup(List<String> names,ScenarioGroup scenarioGroup) {
		super();			
		names.add("Gy");
		names.add("Rx");
		names.add("Gxx");
		names.add("S9");
		names.add("Sd");
		m_names = names;
		ec_scenariogroup = scenarioGroup;		
		System.out.println(ec_scenariogroup.getAppid()+" " +ec_scenariogroup.getIpport()+ " "+ec_scenariogroup.getName());
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setModal(true);
		setTitle("Interface Detail");
		setBounds(400, 300, 500,250);
		m_contentPane = new JPanel();
		m_contentPane.setBorder(new MatteBorder(5, 5, 5, 5, (Color) null));
		setContentPane(m_contentPane);
		//
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 0, 0, 0 };
		gridBagLayout.rowHeights = new int[] { 0, 0, 0, 0 };
		gridBagLayout.columnWeights = new double[] { 0.0, 1.0, 1.0E-4 };
		gridBagLayout.rowWeights = new double[] { 0.0, 0.0, 0.0, 1.0E-4 };
		m_contentPane.setLayout(gridBagLayout);
		//
		{
			JLabel lblName = new JLabel("Interface Name");
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.anchor = GridBagConstraints.EAST;
			gbc.insets = new Insets(5, 5, 5, 5);
			gbc.gridx = 0;
			gbc.gridy = 0;
			m_contentPane.add(lblName, gbc);
		}
		{
			m_comboBox = new JComboBox();
			m_comboBox.setEditable(true);
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.insets = new Insets(0, 0, 5, 0);
			gbc.fill = GridBagConstraints.BOTH;
			gbc.gridx = 1;
			gbc.gridy = 0;
			m_contentPane.add(m_comboBox, gbc);
		}
		{
			JLabel lblName = new JLabel("IP:Port");
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.anchor = GridBagConstraints.EAST;
			gbc.insets = new Insets(5, 5, 5, 5);
			gbc.gridx = 0;
			gbc.gridy = 1;
			m_contentPane.add(lblName, gbc);
		}
		{
			ip_port =new JTextField();			
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.insets = new Insets(0, 0, 5, 0);
			gbc.fill = GridBagConstraints.BOTH;
			gbc.gridx = 1;
			gbc.gridy = 1;
			m_contentPane.add(ip_port, gbc);
		}
		
		{
			JLabel lblName1 = new JLabel("Host-Id:");
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.anchor = GridBagConstraints.EAST;
			gbc.insets = new Insets(5, 5, 5, 5);
			gbc.gridx = 0;
			gbc.gridy = 2;
			m_contentPane.add(lblName1, gbc);
		}
		{
			 host_id =new JTextField();						 
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.insets = new Insets(0, 0, 5, 0);
			gbc.fill = GridBagConstraints.BOTH;
			gbc.gridx = 1;
			gbc.gridy = 2;
			m_contentPane.add(host_id, gbc);
		}
		
	
		{
			JLabel lblName2 = new JLabel("Realm:");
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.anchor = GridBagConstraints.EAST;
			gbc.insets = new Insets(5, 5, 5, 5);
			gbc.gridx = 0;
			gbc.gridy = 3;
			m_contentPane.add(lblName2, gbc);
		}
		{
			 realm =new JTextField();			 
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.insets = new Insets(0, 0, 5, 0);
			gbc.fill = GridBagConstraints.BOTH;
			gbc.gridx = 1;
			gbc.gridy = 3;
			m_contentPane.add(realm, gbc);
		}
		
		{
			JLabel lblName3 = new JLabel("Application-ID:");
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.anchor = GridBagConstraints.EAST;
			gbc.insets = new Insets(5, 5, 5, 5);
			gbc.gridx = 0;
			gbc.gridy = 4;
			m_contentPane.add(lblName3, gbc);
		}
		{
			
			 app_id=new JTextField();			 
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.insets = new Insets(0, 0, 5, 0);
			gbc.fill = GridBagConstraints.BOTH;
			gbc.gridx = 1;
			gbc.gridy = 4;
			m_contentPane.add(app_id, gbc);
		}
		{
			m_buttonOk = new JButton("OK");
			m_buttonOk.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {					
					setVisible(false);
				}
			});
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.anchor = GridBagConstraints.EAST;
			gbc.gridx = 2;
			gbc.gridy = 5;
			m_contentPane.add(m_buttonOk, gbc);
		}
	
		initDataBindings();
	}
	protected void initDataBindings() {		
		JComboBoxBinding<String, List<String>, JComboBox> jComboBinding = SwingBindings.createJComboBoxBinding(AutoBinding.UpdateStrategy.READ, m_names, m_comboBox);
		jComboBinding.bind();
		//
		BeanProperty<ScenarioGroup, String> phoneGroupBeanProperty = BeanProperty.create("name");
		BeanProperty<JComboBox, String> jComboBoxBeanProperty = BeanProperty.create("selectedItem");
		AutoBinding<ScenarioGroup, String, JComboBox, String> autoBinding = Bindings.createAutoBinding(AutoBinding.UpdateStrategy.READ_WRITE, ec_scenariogroup, phoneGroupBeanProperty, m_comboBox, jComboBoxBeanProperty);
		autoBinding.bind();		
		BeanProperty<ScenarioGroup, String> phoneGroupBeanProperty1 = BeanProperty.create("ipport");
		BeanProperty<JTextField, String> txtBoxBeanProperty = BeanProperty.create("text");
		AutoBinding<ScenarioGroup, String, JTextField, String> autoBinding1 = Bindings.createAutoBinding(AutoBinding.UpdateStrategy.READ_WRITE, ec_scenariogroup, phoneGroupBeanProperty1, ip_port, txtBoxBeanProperty);
		autoBinding1.bind();	
		BeanProperty<ScenarioGroup, String> phoneGroupBeanProperty2 = BeanProperty.create("hostid");
		BeanProperty<JTextField, String> txtBoxBeanProperty1 = BeanProperty.create("text");
		AutoBinding<ScenarioGroup, String, JTextField, String> autoBinding2 = Bindings.createAutoBinding(AutoBinding.UpdateStrategy.READ_WRITE, ec_scenariogroup, phoneGroupBeanProperty2, host_id, txtBoxBeanProperty1);
		autoBinding2.bind();
		BeanProperty<ScenarioGroup, String> phoneGroupBeanProperty3 = BeanProperty.create("realm");
		BeanProperty<JTextField, String> txtBoxBeanProperty2 = BeanProperty.create("text");
		AutoBinding<ScenarioGroup, String, JTextField, String> autoBinding3 = Bindings.createAutoBinding(AutoBinding.UpdateStrategy.READ_WRITE, ec_scenariogroup, phoneGroupBeanProperty3, realm, txtBoxBeanProperty2);
		autoBinding3.bind();
		BeanProperty<ScenarioGroup, String> phoneGroupBeanProperty4 = BeanProperty.create("appid");
		BeanProperty<JTextField, String> txtBoxBeanProperty3 = BeanProperty.create("text");
		AutoBinding<ScenarioGroup, String, JTextField, String> autoBinding4 = Bindings.createAutoBinding(AutoBinding.UpdateStrategy.READ_WRITE, ec_scenariogroup, phoneGroupBeanProperty4, app_id, txtBoxBeanProperty3);
		autoBinding4.bind();
	}

}
